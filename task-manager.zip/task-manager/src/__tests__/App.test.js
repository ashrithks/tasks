import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import App from '../App';
import Modal from 'react-modal';

jest
  .spyOn(Modal, "setAppElement")
  .mockImplementation(param => console.log(`setAppElement:'${param}'`));
describe('App Component', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  test('renders the component correctly', () => {
    render(<App />);
    
    expect(screen.getByText('Task Manager')).toBeInTheDocument();
    expect(screen.getByText('Add Task')).toBeInTheDocument();
  });

  test('opens and closes the "Add Task" modal', () => {
    render(<App />);
    
    fireEvent.click(screen.getByText('Add Task'));
    expect(screen.getByText('Add New Task')).toBeInTheDocument();

    fireEvent.click(screen.getByTestId('closeAddModal'));
    expect(screen.queryByText('Add New Task')).not.toBeInTheDocument();
  });

  test('adds a new task', () => {
    render(<App />);
    
    fireEvent.click(screen.getByText('Add Task'));
    fireEvent.change(screen.getByPlaceholderText('Task Description'), {
      target: { value: 'New Task' },
    });
    fireEvent.change(screen.getByTestId('dueDate'), {
      target: { value: '2023-10-10' },
    });
    fireEvent.click(screen.getByTestId('saveTask'));

    expect(screen.getByText('New Task')).toBeInTheDocument();
  });

  test('opens and closes the "Edit Task" modal', () => {
    render(<App />);
    
    fireEvent.click(screen.getByText('Add Task'));
    fireEvent.change(screen.getByPlaceholderText('Task Description'), {
      target: { value: 'Task to Edit' },
    });
    fireEvent.change(screen.getByTestId('dueDate'), {
      target: { value: '2023-10-10' },
    });
    fireEvent.click(screen.getByTestId('saveTask'));

    fireEvent.click(screen.getByText('Edit'));
    expect(screen.getByText('Edit Task')).toBeInTheDocument();

    fireEvent.click(screen.getByTestId('closeEditModal'));
    expect(screen.queryByText('Edit Task')).not.toBeInTheDocument();
  });

  test('updates an existing task', () => {
    render(<App />);
    
    fireEvent.click(screen.getByText('Add Task'));
    fireEvent.change(screen.getByPlaceholderText('Task Description'), {
      target: { value: 'Task to Edit' },
    });
    fireEvent.change(screen.getByTestId('dueDate'), {
      target: { value: '2023-10-10' },
    });
    fireEvent.click(screen.getByTestId('saveTask'));

    fireEvent.click(screen.getByText('Edit'));
    fireEvent.change(screen.getByPlaceholderText('Task Description'), {
      target: { value: 'Updated Task' },
    });
    fireEvent.click(screen.getByTestId('saveTask'));

    expect(screen.getByText('Updated Task')).toBeInTheDocument();
    expect(screen.queryByText('Task to Edit')).not.toBeInTheDocument();
  });

  test('deletes a task', () => {
    render(<App />);
    
    fireEvent.click(screen.getByText('Add Task'));
    fireEvent.change(screen.getByPlaceholderText('Task Description'), {
      target: { value: 'Task to Delete' },
    });
    fireEvent.change(screen.getByTestId('dueDate'), {
      target: { value: '2023-10-10' },
    });
    fireEvent.click(screen.getByTestId('saveTask'));

    fireEvent.click(screen.getByText('Delete'));
    expect(screen.queryByText('Task to Delete')).not.toBeInTheDocument();
  });

  test('completes a task', () => {
    render(<App />);
    
    fireEvent.click(screen.getByText('Add Task'));
    fireEvent.change(screen.getByPlaceholderText('Task Description'), {
      target: { value: 'Task to Complete' },
    });
    fireEvent.change(screen.getByTestId('dueDate'), {
      target: { value: '2023-10-10' },
    });
    fireEvent.click(screen.getByTestId('saveTask'));

    fireEvent.click(screen.getByText('Complete'));
    expect(screen.getByText('Undo')).toBeInTheDocument();

    fireEvent.click(screen.getByText('Undo'));
    expect(screen.getByText('Complete')).toBeInTheDocument();
  });

  test('deletes selected tasks', () => {
    render(<App />);
    
    fireEvent.click(screen.getByText('Add Task'));
    fireEvent.change(screen.getByPlaceholderText('Task Description'), {
      target: { value: 'Task 1' },
    });
    fireEvent.change(screen.getByTestId('dueDate'), {
      target: { value: '2023-10-10' },
    });
    fireEvent.click(screen.getByTestId('saveTask'));

    fireEvent.click(screen.getByText('Add Task'));
    fireEvent.change(screen.getByPlaceholderText('Task Description'), {
      target: { value: 'Task 2' },
    });
    fireEvent.change(screen.getByTestId('dueDate'), {
      target: { value: '2023-10-11' },
    });
    fireEvent.click(screen.getByTestId('saveTask'));

    const checkboxes = screen.getAllByRole('checkbox');
    fireEvent.click(checkboxes[0]); // Select All checkbox
    fireEvent.click(screen.getByTestId('deleteSelected'));

    expect(screen.queryByText('Task 1')).not.toBeInTheDocument();
    expect(screen.queryByText('Task 2')).not.toBeInTheDocument();
  });
});