import React, { useState, useEffect, useRef } from 'react';
import TaskList from './Components/TaskList';
import AddTask from './Components/AddTask';
import Modal from 'react-modal';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTimes } from '@fortawesome/free-solid-svg-icons';
import './App.css';

const App = () => {
  const [tasks, setTasks] = useState(() => {
    const savedTasks = localStorage.getItem('tasks');
    return savedTasks ? JSON.parse(savedTasks) : [];
  });
  const tasksRef = useRef(tasks);

  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [editModalIsOpen, setEditModalIsOpen] = useState(false);
  const [currentTask, setCurrentTask] = useState(null);

  useEffect(() => {
    localStorage.setItem('tasks', JSON.stringify(tasks));
    tasksRef.current = tasks;
  }, [tasks]);

  const addTask = (task) => {
    setTasks([...tasks, task]);
  };

  const updateTask = (updatedTask) => {
    setTasks(tasks.map(task => task.id === updatedTask.id ? updatedTask : task));
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter((task) => task.id !== id));
  };

  const deleteSelectedTasks = (taskSelected) => {
    setTasks(tasks.filter((task) => !taskSelected.includes(task.id)));
  };

  const completeTask = (id) => {
    const newTasks = tasksRef.current.map((task) =>
      task.id === id ? { ...task, completed: !task.completed } : task
    )
    setTasks(newTasks);
  };

  const openModal = () => {
    setModalIsOpen(true);
  };

  const closeModal = () => {
    setModalIsOpen(false);
  };

  const openEditModal = (task) => {
    setCurrentTask(task);
    setEditModalIsOpen(true);
  };

  const closeEditModal = () => {
    setEditModalIsOpen(false);
  };

  return (
    <div className="App container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Task Manager</h1>
      <button onClick={openModal} className="bg-blue-500 text-white px-4 py-2 mb-4 rounded-md float-right">Add Task</button>
      <TaskList tasks={tasks} onDelete={deleteTask} onComplete={completeTask} onEdit={openEditModal} deleteSelectedTasks={deleteSelectedTasks}/>
      <Modal
        appElement={document.querySelector('#root')}
        isOpen={modalIsOpen}
        onRequestClose={closeModal}
        contentLabel="Add Task Modal"
        className="modal"
        overlayClassName="overlay"
      >
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl">Add New Task</h2>
          <FontAwesomeIcon data-testid="closeAddModal" icon={faTimes} className="cursor-pointer" onClick={closeModal} />
        </div>
        <AddTask onAdd={(task) => { addTask(task); closeModal(); }} />
      </Modal>

      <Modal
        appElement={document.querySelector('#root')}
        isOpen={editModalIsOpen}
        onRequestClose={closeEditModal}
        contentLabel="Edit Task Modal"
        className="modal"
        overlayClassName="overlay"
      >
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl">Edit Task</h2>
          <FontAwesomeIcon data-testid="closeEditModal" icon={faTimes} className="cursor-pointer" onClick={closeEditModal} />
        </div>
        <AddTask
          onAdd={(task) => { updateTask(task); closeEditModal(); }}
          currentTask={currentTask}
        />
      </Modal>
    </div>
  );
};

export default App;