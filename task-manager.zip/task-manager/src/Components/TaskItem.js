import React from 'react';

const TaskItem = ({ task, onDelete, onComplete, onEdit }) => {
  return (
    <div className="flex space-x-2">
      <button
        id="completeTask"
        data-testid="completeTask"
        onClick={() => onComplete(task.id)}
        className={`px-2 py-1 ${task.completed ? 'bg-gray-500' : 'bg-green-500'} text-white rounded-md`}
      >
        {task.completed ? 'Undo' : 'Complete'}
      </button>
      <button id="editTask"
        data-testid="editTask" onClick={() => onEdit(task)} className="bg-yellow-500 text-white px-2 py-1 rounded-md">Edit</button>
      <button id="deleteTask"
        data-testid="deleteTask" onClick={() => onDelete(task.id)} className="bg-red-500 text-white px-2 py-1 rounded-md">Delete</button>
    </div>
  );
};

export default TaskItem;