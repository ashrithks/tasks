import React, { useState, useEffect } from 'react';

const AddTask = ({ onAdd, currentTask }) => {
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (currentTask) {
      setDescription(currentTask.description);
      setDueDate(currentTask.dueDate);
    }
  }, [currentTask]);

  const validate = () => {
    const newErrors = {};
    if (!description) {
      newErrors.description = 'Description is required';
    }
    if (!dueDate) {
      newErrors.dueDate = 'Due date is required';
    }
    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    const newTask = {
      id: currentTask ? currentTask.id : Date.now(),
      description,
      createdDate: currentTask ? currentTask.createdDate : new Date().toLocaleDateString(),
      dueDate,
      completed: currentTask ? currentTask.completed : false,
    };

    onAdd(newTask);
    setDescription('');
    setDueDate('');
    setErrors({});
  };

  return (
    <form onSubmit={handleSubmit} className="mb-4">
      <div className="mb-2">
        <input
          id="description"
          data-testid="description"
          type="text"
          placeholder="Task Description"
          value={description}
          onChange={(e) => { setErrors({}); setDescription(e.target.value) }}
          className="border p-2 mr-2 w-full"
        />
        {errors.description && <span className="text-red-500">{errors.description}</span>}
      </div>
      <div className="mb-2">
        <input
          id="dueDate"
          data-testid="dueDate"
          type="date"
          value={dueDate}
          onChange={(e) => { setErrors({}); setDueDate(e.target.value) }}
          className="border p-2 mr-2 w-full"
        />
        {errors.dueDate && <span className="text-red-500">{errors.dueDate}</span>}
      </div>
      <button id='saveTask' data-testid="saveTask" type="submit" className="bg-blue-500 text-white px-4 py-2 mt-10 float-right rounded-md">
        {currentTask ? 'Update Task' : 'Add Task'}
      </button>
    </form>
  );
};

export default AddTask;