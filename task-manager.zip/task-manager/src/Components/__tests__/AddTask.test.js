import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import AddTask from '../AddTask';

describe('AddTask Component', () => {
  test('renders the form correctly', () => {
    render(<AddTask onAdd={jest.fn()} />);
    
    expect(screen.getByTestId('description')).toBeInTheDocument();
    expect(screen.getByTestId('dueDate')).toBeInTheDocument();
    expect(screen.getByTestId('saveTask')).toBeInTheDocument();
  });

  test('validates the form inputs and displays error messages', () => {
    render(<AddTask onAdd={jest.fn()} />);
    
    fireEvent.click(screen.getByTestId('saveTask'));

    expect(screen.getByText(/Description is required/i)).toBeInTheDocument();
    expect(screen.getByText(/Due date is required/i)).toBeInTheDocument();
  });

  test('submits the form with valid inputs', () => {
    const onAddMock = jest.fn();
    render(<AddTask onAdd={onAddMock} />);
    
    fireEvent.change(screen.getByTestId('description'), {
      target: { value: 'New Task' },
    });
    fireEvent.change(screen.getByTestId('dueDate'), {
      target: { value: '2023-10-10' },
    });
    fireEvent.click(screen.getByTestId('saveTask'));

    expect(onAddMock).toHaveBeenCalledWith({
      id: expect.any(Number),
      description: 'New Task',
      createdDate: expect.any(String),
      dueDate: '2023-10-10',
      completed: false,
    });
  });

  test('handles the update scenario correctly', () => {
    const currentTask = {
      id: 1,
      description: 'Existing Task',
      createdDate: '2023-10-01',
      dueDate: '2023-10-10',
      completed: false,
    };
    const onAddMock = jest.fn();
    render(<AddTask onAdd={onAddMock} currentTask={currentTask} />);
    
    expect(screen.getByTestId('description').value).toBe('Existing Task');
    expect(screen.getByTestId('dueDate').value).toBe('2023-10-10');
    expect(screen.getByText(/Update Task/i)).toBeInTheDocument();

    fireEvent.change(screen.getByTestId('description'), {
      target: { value: 'Updated Task' },
    });
    fireEvent.click(screen.getByTestId('saveTask'));

    expect(onAddMock).toHaveBeenCalledWith({
      id: 1,
      description: 'Updated Task',
      createdDate: '2023-10-01',
      dueDate: '2023-10-10',
      completed: false,
    });
  });
});