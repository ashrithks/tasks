import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import TaskList from '../TaskList';

describe('TaskList Component', () => {
  const mockTasks = [
    { id: 1, description: 'Task 1', createdDate: '2023-10-01', dueDate: '2023-10-10', completed: false },
    { id: 2, description: 'Task 2', createdDate: '2023-10-02', dueDate: '2023-10-11', completed: false },
  ];

  const onDeleteMock = jest.fn();
  const onCompleteMock = jest.fn();
  const onEditMock = jest.fn();
  const deleteSelectedTasksMock = jest.fn();

  test('renders the table correctly', () => {
    render(
      <TaskList 
        tasks={mockTasks}
        onDelete={onDeleteMock}
        onComplete={onCompleteMock}
        onEdit={onEditMock}
        deleteSelectedTasks={deleteSelectedTasksMock}
      />
    );
    expect(screen.getByTestId('taskListTable')).toBeInTheDocument();
    expect(screen.getByText('Task 1')).toBeInTheDocument();
    expect(screen.getByText('Task 2')).toBeInTheDocument();
  });

  test('selects individual tasks', () => {
    render(
        <TaskList 
          tasks={mockTasks}
          onDelete={onDeleteMock}
          onComplete={onCompleteMock}
          onEdit={onEditMock}
          deleteSelectedTasks={deleteSelectedTasksMock}
        />
      );
    const checkboxes = screen.getAllByRole('checkbox');
    
    fireEvent.click(checkboxes[1]);
    expect(checkboxes[1].checked).toBe(true);
    
    fireEvent.click(checkboxes[2]);
    expect(checkboxes[2].checked).toBe(true);
    
    fireEvent.click(checkboxes[1]);
    expect(checkboxes[1].checked).toBe(false);
  });

  test('calls the deleteSelectedTasks function when the "Delete Selected" button is clicked', () => {
    render(
        <TaskList 
          tasks={mockTasks}
          onDelete={onDeleteMock}
          onComplete={onCompleteMock}
          onEdit={onEditMock}
          deleteSelectedTasks={deleteSelectedTasksMock}
        />
      );
      const selectAllCheckbox = screen.getAllByRole('checkbox')[0];
      const deleteSelectedButton = screen.getByTestId('deleteSelected');
  
      fireEvent.click(selectAllCheckbox);
      fireEvent.click(deleteSelectedButton);
  
      expect(deleteSelectedTasksMock).toHaveBeenCalledWith([1, 2]);
  });

});