import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import TaskItem from '../TaskItem';

describe('TaskItem Component', () => {
  const mockTask = {
    id: 1,
    description: 'Test Task',
    completed: false,
  };

  const onCompleteMock = jest.fn();
  const onEditMock = jest.fn();
  const onDeleteMock = jest.fn();

  test('renders the component correctly', () => {
    render(
      <TaskItem 
        task={mockTask}
        onComplete={onCompleteMock}
        onEdit={onEditMock}
        onDelete={onDeleteMock}
      />
    );
    expect(screen.getByText('Complete')).toBeInTheDocument();
    expect(screen.getByText('Edit')).toBeInTheDocument();
    expect(screen.getByText('Delete')).toBeInTheDocument();
  });

  test('calls the onComplete function when the "Complete" button is clicked', () => {
    render(
      <TaskItem 
        task={mockTask}
        onComplete={onCompleteMock}
        onEdit={onEditMock}
        onDelete={onDeleteMock}
      />
    );
    fireEvent.click(screen.getByTestId('completeTask'));
    expect(onCompleteMock).toHaveBeenCalledWith(1);
  });

  test('calls the onEdit function when the "Edit" button is clicked', () => {
    render(
      <TaskItem 
        task={mockTask}
        onComplete={onCompleteMock}
        onEdit={onEditMock}
        onDelete={onDeleteMock}
      />
    );
    fireEvent.click(screen.getByTestId('editTask'));
    expect(onEditMock).toHaveBeenCalledWith(mockTask);
  });

  test('calls the onDelete function when the "Delete" button is clicked', () => {
    render(
      <TaskItem 
        task={mockTask}
        onComplete={onCompleteMock}
        onEdit={onEditMock}
        onDelete={onDeleteMock}
      />
    );
    fireEvent.click(screen.getByTestId('deleteTask'));
    expect(onDeleteMock).toHaveBeenCalledWith(1);
  });
});