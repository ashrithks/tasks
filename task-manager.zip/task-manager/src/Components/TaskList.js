import React, { useState, useMemo } from 'react';
import { useTable, useSortBy } from 'react-table';
import TaskItem from './TaskItem';

const TaskList = ({ tasks, onDelete, onComplete, onEdit, deleteSelectedTasks }) => {
    const [selectedTasks, setSelectedTasks] = useState([]);

    const handleSelectTask = (id) => {
        setSelectedTasks((prevSelectedTasks) => {
            if (prevSelectedTasks.includes(id)) {
                return prevSelectedTasks.filter(taskId => taskId !== id);
            } else {
                return [...prevSelectedTasks, id];
            }
        });
    };

    const handleSelectAllTasks = () => {
        if (selectedTasks.length === tasks.length) {
            setSelectedTasks([]);
        } else {
            setSelectedTasks(tasks.map(task => task.id));
        }
    };

    const handleDeleteSelected = () => {
        deleteSelectedTasks(selectedTasks);
        setSelectedTasks([]);
    };

    const columns = useMemo(
        () => [
            {
                Header: ({ getToggleAllRowsSelectedProps }) => (
                    <div>
                        <input
                            type="checkbox"
                            checked={selectedTasks.length === tasks.length && tasks.length > 0}
                            onChange={handleSelectAllTasks}
                        />
                    </div>
                ),
                accessor: 'select',
                disableSortBy: true,
                Cell: ({ row }) => (
                    <input
                        type="checkbox"
                        checked={selectedTasks.includes(row.original.id)}
                        onChange={() => handleSelectTask(row.original.id)}
                    />
                ),
            },
            {
                Header: 'Task Description',
                accessor: 'description',
            },
            {
                Header: 'Created Date',
                accessor: 'createdDate',
            },
            {
                Header: 'Due Date',
                accessor: 'dueDate',
            },
            {
                Header: 'Actions',
                accessor: 'actions',
                disableSortBy: true,
                Cell: ({ row }) => (
                    <TaskItem
                        task={row.original}
                        onDelete={onDelete}
                        onComplete={onComplete}
                        onEdit={onEdit}
                    />
                ),
            },
        ],
        [onComplete, onDelete, onEdit, selectedTasks, tasks]
    );

    const data = useMemo(() => tasks, [tasks]);

    const { getTableProps, getTableBodyProps, headerGroups, rows, prepareRow } =
        useTable({ columns, data }, useSortBy);

    return (
        <div>
            <button
                id="deleteSelected"
                data-testid="deleteSelected"
                onClick={handleDeleteSelected}
                className={`px-4 py-2 mb-4 rounded-md float-end mr-5 ${selectedTasks.length === 0 ? 'bg-gray-400 cursor-not-allowed' : 'bg-red-500 text-white cursor-pointer'
                    }`}
                disabled={selectedTasks.length === 0}
            >
                Delete Selected
            </button>
            <table {...getTableProps()} className="min-w-full bg-white" id="taskListTable"
                data-testid="taskListTable">
                <thead>
                    {headerGroups.map(headerGroup => (
                        <tr {...headerGroup.getHeaderGroupProps()} className="bg-gray-800 text-white">
                            {headerGroup.headers.map(column => (
                                <th {...column.getHeaderProps(column.getSortByToggleProps())} className="py-2 px-4">
                                    {column.render('Header')}
                                    {!column.disableSortBy && (
                                        <span>
                                            {column.isSorted
                                                ? column.isSortedDesc
                                                    ? ' 🔽'
                                                    : ' 🔼'
                                                : ''}
                                        </span>
                                    )}
                                </th>
                            ))}
                        </tr>
                    ))}
                </thead>
                <tbody {...getTableBodyProps()}>
                    {rows.map(row => {
                        prepareRow(row);
                        return (
                            <tr {...row.getRowProps()} className="border-b">
                                {row.cells.map(cell => (
                                    <td {...cell.getCellProps()} className="py-2 px-4">{cell.render('Cell')}</td>
                                ))}
                            </tr>
                        );
                    })}
                </tbody>
            </table>
        </div>
    );
};

export default TaskList;