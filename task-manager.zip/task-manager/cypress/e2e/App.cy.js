describe('App spec', () => {
  beforeEach(() => {
    cy.visit('http://localhost:3000/')
  })

  it('passes', () => {
    cy.visit('http://localhost:3000/')
  })

  it('Add New task', () => {
    cy.get('.bg-blue-500').click();
    cy.get('[data-testid="description"]').type('New Task');
    cy.get('[data-testid="dueDate"]').type('2023-10-10');
    cy.get('[data-testid="saveTask"]').click();
    cy.contains('New Task').should('exist');
  })

  it('Edit Task', () => {
    cy.get('.bg-blue-500').click();
    cy.get('[data-testid="description"]').type('New Task');
    cy.get('[data-testid="dueDate"]').type('2023-10-10');
    cy.get('[data-testid="saveTask"]').click();
    cy.get('[data-testid="editTask"]').click();
    cy.get('[data-testid="description"]').clear().type('Updated Task');
    cy.get('[data-testid="saveTask"]').click();
    cy.contains('Updated Task').should('exist');
  })

  it('Complete or Undo Task', () => {
    cy.get('.bg-blue-500').click();
    cy.get('[data-testid="description"]').type('New Task');
    cy.get('[data-testid="dueDate"]').type('2023-10-10');
    cy.get('[data-testid="saveTask"]').click();
    cy.get('[data-testid="completeTask"]').click();
    cy.get('[data-testid="completeTask"]').should('contain', 'Undo');
    cy.get('[data-testid="completeTask"]').click();
    cy.get('[data-testid="completeTask"]').should('contain', 'Complete');
  })

  it('Delete Task', () => {
    cy.get('.bg-blue-500').click();
    cy.get('[data-testid="description"]').type('New Task');
    cy.get('[data-testid="dueDate"]').type('2023-10-10');
    cy.get('[data-testid="saveTask"]').click();
    cy.get('[data-testid="deleteTask"]').click();
    cy.contains('New Task').should('not.exist');
  })

  it('Validation Error', () => {
    cy.get('.bg-blue-500').click();
    cy.get('[data-testid="saveTask"]').click();
    cy.get('.text-red-500').should('have.length', 2);
  })

  it('Delete Selected Task', () => {
    cy.get('.bg-blue-500').click();
    cy.get('[data-testid="description"]').type('Task 1');
    cy.get('[data-testid="dueDate"]').type('2023-10-10');
    cy.get('[data-testid="saveTask"]').click();
    cy.get('.bg-blue-500').click();
    cy.get('[data-testid="description"]').type('Task 2');
    cy.get('[data-testid="dueDate"]').type('2023-10-10');
    cy.get('[data-testid="saveTask"]').click();
    cy.get('div > input').click();
    cy.get('[data-testid="deleteSelected"]').click();
    cy.contains('Task 1').should('not.exist');
    cy.contains('Task 2').should('not.exist');
  })

})