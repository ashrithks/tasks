const { defineConfig } = require("cypress");

module.exports = defineConfig({
  e2e: {
    setupNodeEvents(on, config) {
      // implement node event listeners here
    },
    experimentalMemoryManagement: true,
    numTestsKeptInMemory: 1,
    experimentalStudio: true,
    retries: {
      experimentalStrategy: 'detect-flake-but-always-fail',
      experimentalOptions: {
        maxRetries: 1,
        stopIfAnyPassed: true,
      },
      openMode: false,
      runMode: false,
    },
    "reporter": "mochawesome",
    "reporterOptions": {
      "charts": true,
      "overwrite": false,
      "html": false,
      "json": true,
      "reportDir": "cypress/report/mochawesome-report"
    },
    "screenshotsFolder": "cypress/report/assets",
    "videosFolder": "cypress/report/videos",
    "video": true,
    viewportWidth: 1536, // Set the viewport width
    viewportHeight: 960,   // Set the viewport height
    pageLoadTimeout: 120000, // Set the page load timeout
    defaultCommandTimeout: 10000
  },
});