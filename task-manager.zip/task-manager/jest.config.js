module.exports = {
    collectCoverageFrom: [
      "src/**/*.{js,jsx}",
      "!src/index.js",       // Exclude specific files
      "!src/serviceWorker.js" // Exclude specific files
    ],
    coverageDirectory: "coverage",
    coverageReporters: ["text", "lcov", "html"],
  };